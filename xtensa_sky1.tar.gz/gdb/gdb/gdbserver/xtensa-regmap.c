/* Customized table mapping between kernel xtregset and GDB register cache.

   Copyright (c) 2007-2010 Tensilica Inc.

   Permission is hereby granted, free of charge, to any person obtaining
   a copy of this software and associated documentation files (the
   "Software"), to deal in the Software without restriction, including
   without limitation the rights to use, copy, modify, merge, publish,
   distribute, sublicense, and/or sell copies of the Software, and to
   permit persons to whom the Software is furnished to do so, subject to
   the following conditions:

   The above copyright notice and this permission notice shall be included
   in all copies or substantial portions of the Software.

   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
   EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
   IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
   CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
   TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
   SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.  */


typedef struct {
  int   gdb_regnum;
  int   gdb_offset;
  int   ptrace_cp_offset;
  int   ptrace_offset;
  int   size;
  int   coproc;
  int   dbnum;
  char* name
;} xtensa_regtable_t;

#define XTENSA_ELF_XTREG_SIZE	400

const xtensa_regtable_t  xtensa_regmap_table[] = {
  /* gnum,gofs,cpofs,ofs,siz,cp, dbnum,  name */
  {   75, 300,   0,   0,  4, -1, 0x0204, "br" },
  {   76, 304,  16,  32,  4,  1, 0x03f0, "ae_ovf_sar" },
  {   77, 308,  20,  36,  4,  1, 0x03f1, "ae_bithead" },
  {   78, 312,  24,  40,  4,  1, 0x03f2, "ae_ts_fts_bu_bp" },
  {   79, 316,  28,  44,  4,  1, 0x03f3, "ae_cw_sd_no" },
  {   80, 320,  32,  48,  4,  1, 0x03f6, "ae_cbegin0" },
  {   81, 324,  36,  52,  4,  1, 0x03f7, "ae_cend0" },
  {   82, 328,  40,  56,  4,  1, 0x03f8, "ae_cbegin1" },
  {   83, 332,  44,  60,  4,  1, 0x03f9, "ae_cend1" },
  {   84, 336,  48,  64,  4,  1, 0x03fa, "ae_cbegin2" },
  {   85, 340,  52,  68,  4,  1, 0x03fb, "ae_cend2" },
  {   86, 344,  56,  72,  8,  1, 0x1000, "aed0" },
  {   87, 352,  64,  80,  8,  1, 0x1001, "aed1" },
  {   88, 360,  72,  88,  8,  1, 0x1002, "aed2" },
  {   89, 368,  80,  96,  8,  1, 0x1003, "aed3" },
  {   90, 376,  88, 104,  8,  1, 0x1004, "aed4" },
  {   91, 384,  96, 112,  8,  1, 0x1005, "aed5" },
  {   92, 392, 104, 120,  8,  1, 0x1006, "aed6" },
  {   93, 400, 112, 128,  8,  1, 0x1007, "aed7" },
  {   94, 408, 120, 136,  8,  1, 0x1008, "aed8" },
  {   95, 416, 128, 144,  8,  1, 0x1009, "aed9" },
  {   96, 424, 136, 152,  8,  1, 0x100a, "aed10" },
  {   97, 432, 144, 160,  8,  1, 0x100b, "aed11" },
  {   98, 440, 152, 168,  8,  1, 0x100c, "aed12" },
  {   99, 448, 160, 176,  8,  1, 0x100d, "aed13" },
  {  100, 456, 168, 184,  8,  1, 0x100e, "aed14" },
  {  101, 464, 176, 192,  8,  1, 0x100f, "aed15" },
  {  102, 472, 184, 200,  8,  1, 0x1010, "aed16" },
  {  103, 480, 192, 208,  8,  1, 0x1011, "aed17" },
  {  104, 488, 200, 216,  8,  1, 0x1012, "aed18" },
  {  105, 496, 208, 224,  8,  1, 0x1013, "aed19" },
  {  106, 504, 216, 232,  8,  1, 0x1014, "aed20" },
  {  107, 512, 224, 240,  8,  1, 0x1015, "aed21" },
  {  108, 520, 232, 248,  8,  1, 0x1016, "aed22" },
  {  109, 528, 240, 256,  8,  1, 0x1017, "aed23" },
  {  110, 536, 248, 264,  8,  1, 0x1018, "aed24" },
  {  111, 544, 256, 272,  8,  1, 0x1019, "aed25" },
  {  112, 552, 264, 280,  8,  1, 0x101a, "aed26" },
  {  113, 560, 272, 288,  8,  1, 0x101b, "aed27" },
  {  114, 568, 280, 296,  8,  1, 0x101c, "aed28" },
  {  115, 576, 288, 304,  8,  1, 0x101d, "aed29" },
  {  116, 584, 296, 312,  8,  1, 0x101e, "aed30" },
  {  117, 592, 304, 320,  8,  1, 0x101f, "aed31" },
  {  118, 600, 320, 336, 16,  1, 0x1020, "u0" },
  {  119, 616, 336, 352, 16,  1, 0x1021, "u1" },
  {  120, 632, 352, 368, 16,  1, 0x1022, "u2" },
  {  121, 648, 368, 384, 16,  1, 0x1023, "u3" },
  {  122, 664, 312, 328,  1,  1, 0x1024, "aep0" },
  {  123, 665, 313, 329,  1,  1, 0x1025, "aep1" },
  {  124, 666, 314, 330,  1,  1, 0x1026, "aep2" },
  {  125, 667, 315, 331,  1,  1, 0x1027, "aep3" },
  {  126, 668,   0,  16,  4,  1, 0x1029, "ae_zbiasv8c" },
  {  127, 672,   8,  24,  4,  1, 0x102a, "fcr_fsr" },
  { 0 }
};

